window.wpcom = window.wpcom || {};
window._stq = window._stq || [];
function st_go(t) {
  window._stq.push(["view", t]);
}
function linktracker_init(t, e) {
  window._stq.push(["clickTrackerInit", t, e]);
}
window.wpcom.stats = (function () {
  var t = (function () {
    var t, n;
    var o = function (t, e, n) {
      if ("function" === typeof t.addEventListener) {
        t.addEventListener(e, n);
      } else if ("object" === typeof t.attachEvent) {
        t.attachEvent("on" + e, n);
      }
    };
    var i = function (t) {
      if ("object" === typeof t && t.target) {
        return t.target;
      } else {
        return window.event.srcElement;
      }
    };
    var r = function (t) {
      var n = 0;
      if ("object" === typeof InstallTrigger) n = 100;
      if (7 === e()) n = 100;
      f(i(t), n);
    };
    var c = function (t) {
      f(i(t), 0);
    };
    var a = function (t) {
      var e = document.location;
      if (e.host === t.host) return true;
      if ("" === t.host) return true;
      if (e.protocol === t.protocol && e.host === t.hostname) {
        if ("http:" === e.protocol && e.host + ":80" === t.host) return true;
        if ("https:" === e.protocol && e.host + ":443" === t.host) return true;
      }
      return false;
    };
    var f = function (e, o) {
      try {
        if ("object" !== typeof e) return;
        while ("A" !== e.nodeName) {
          if ("undefined" === typeof e.nodeName) return;
          if ("object" !== typeof e.parentNode) return;
          e = e.parentNode;
        }
        if (a(e) && !e.href.includes("/wp-content/uploads")) return;
        if ("javascript:" === e.protocol) return;
        window._stq.push([
          "click",
          {
            s: "2",
            u: e.href,
            r: "undefined" !== typeof e.rel ? e.rel : "0",
            b: "undefined" !== typeof t ? t : "0",
            p: "undefined" !== typeof n ? n : "0",
          },
        ]);
        if (o) {
          var i = new Date();
          var r = i.getTime() + o;
          while (true) {
            i = new Date();
            if (i.getTime() > r) {
              break;
            }
          }
        }
      } catch (t) {}
    };
    var u = {
      init: function (e, i) {
        t = e;
        n = i;
        if (document.body) {
          o(document.body, "click", r);
          o(document.body, "contextmenu", c);
        } else if (document) {
          o(document, "click", r);
          o(document, "contextmenu", c);
        }
      },
    };
    return u;
  })();
  var e = function () {
    var t = 0;
    if (
      "object" === typeof navigator &&
      navigator.appName == "Microsoft Internet Explorer"
    ) {
      var e = navigator.userAgent.match(/MSIE ([0-9]{1,})[\.0-9]{0,}/);
      if (null !== e) {
        t = parseInt(e[1]);
      }
    }
    return t;
  };
  var n = function (t) {
    var e,
      n = [];
    for (e in t) {
      if (t.hasOwnProperty(e)) {
        n.push(encodeURIComponent(e) + "=" + encodeURIComponent(t[e]));
      }
    }
    return n.join("&");
  };
  var o = function (t, e, n) {
    var o = new Image();
    o.src =
      document.location.protocol +
      "//pixel.wp.com/" +
      t +
      "?" +
      e +
      "&rand=" +
      Math.random();
    o.alt = "";
    o.width = "6";
    o.height = "5";
    if ("string" === typeof n && document.body) {
      o.id = n;
      document.body.appendChild(o);
    }
  };
  var i = function (t) {
    this.a = 1;
    if (t && t.length) {
      for (var e = 0; e < t.length; e++) {
        this.push(t[e]);
      }
    }
  };
  i.prototype.push = function (t) {
    if (t) {
      if ("object" === typeof t && t.length) {
        var e = t.splice(0, 1);
        if (c[e]) c[e].apply(null, t);
      } else if ("function" === typeof t) {
        t();
      }
    }
  };
  var r = function () {
    if (!window._stq.a) {
      window._stq = new i(window._stq);
    }
  };
  var c = {
    view: function (t) {
      t.host = document.location.host;
      t.ref = document.referrer;
      t.fcp = d();
      try {
        if (typeof window !== "undefined" && window.location) {
          var e = new URL(window.location.href).searchParams;
          var i =
            e && Array.from(e.entries()).filter(([t]) => t.startsWith("utm_"));
          var r = i ? Object.fromEntries(i) : {};
          var c = Array.from(Object.entries(t)).filter(
            ([t]) => !t.startsWith("utm_")
          );
          t = c ? Object.fromEntries(c) : t;
          t = Object.assign(t, r);
        }
      } catch (t) {
        if (window.console && window.console.log) {
          window.console.log(t);
        }
      }
      o("g.gif", n(t), "wpstats");
    },
    click: function (t) {
      o("c.gif", n(t), false);
    },
    clickTrackerInit: function (e, n) {
      t.init(e, n);
    },
  };
  var a = function () {
    return typeof document.hidden !== "undefined" && document.hidden;
  };
  var f = function () {
    if (!document.hidden) {
      document.removeEventListener("visibilitychange", f);
      r();
    }
  };
  var u = function () {
    document.addEventListener("visibilitychange", f);
  };
  function d() {
    if (window.performance) {
      var t = window.performance.getEntriesByType("paint");
      for (var e = 0; e < t.length; e++) {
        if (t[e]["name"] === "first-contentful-paint") {
          return Math.round(t[e]["startTime"]);
        }
      }
    }
    return 0;
  }
  if (
    6 === e() &&
    "complete" !== document.readyState &&
    "object" === typeof document.attachEvent
  ) {
    document.attachEvent("onreadystatechange", function (t) {
      if ("complete" === document.readyState) window.setTimeout(r, 250);
    });
  } else {
    if (a()) {
      u();
    } else {
      r();
    }
  }
  return c;
})();
